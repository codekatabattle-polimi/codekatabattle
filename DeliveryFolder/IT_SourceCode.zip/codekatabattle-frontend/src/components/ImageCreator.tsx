
export const ImageCreator= ({username}: {username :string}) => {
    return(<><img src={`https://github.com/${username}.png`}/></>)
}