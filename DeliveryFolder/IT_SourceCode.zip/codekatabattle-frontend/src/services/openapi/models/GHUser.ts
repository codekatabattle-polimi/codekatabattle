/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type GHUser = {
    id?: number;
    login?: string;
    node_id?: string;
    avatar_url?: string;
    gravatar_id?: string;
    url?: string;
    html_url?: string;
    repos_url?: string;
    type?: string;
    site_admin?: boolean;
};

