/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Tournament } from './Tournament';
export type TournamentCoordinator = {
    id?: number;
    createdAt?: string;
    updatedAt?: string;
    tournament?: Tournament;
    username?: string;
};

