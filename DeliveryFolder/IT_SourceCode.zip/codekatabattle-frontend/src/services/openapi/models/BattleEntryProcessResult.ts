/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { BattleTestResult } from './BattleTestResult';
import type { SATResult } from './SATResult';
export type BattleEntryProcessResult = {
    testResults: Array<BattleTestResult>;
    satResult?: SATResult;
};

