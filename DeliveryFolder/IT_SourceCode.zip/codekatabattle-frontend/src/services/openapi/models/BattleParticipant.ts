/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Battle } from './Battle';
export type BattleParticipant = {
    id?: number;
    createdAt?: string;
    updatedAt?: string;
    battle?: Battle;
    username?: string;
    score?: number;
    receivedOME?: boolean;
};

