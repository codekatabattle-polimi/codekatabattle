package it.polimi.codekatabattle.models.github;

public class GHApp {
    public String url;
    public String name;
    public String client_id;
}
