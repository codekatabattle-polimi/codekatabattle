package it.polimi.codekatabattle.entities;

public enum BattleTestPrivacy {
    PUBLIC,
    PRIVATE,
}
