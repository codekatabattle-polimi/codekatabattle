package it.polimi.codekatabattle.config;

public class APIConstants {

    public static final String DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

}
