package it.polimi.codekatabattle.entities;

public enum BattleLanguage {
    GOLANG,
    PYTHON,
}
