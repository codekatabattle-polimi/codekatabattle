package it.polimi.codekatabattle.models.oauth;

public enum AuthOrigin {
    SWAGGER,
    FRONTEND
}
