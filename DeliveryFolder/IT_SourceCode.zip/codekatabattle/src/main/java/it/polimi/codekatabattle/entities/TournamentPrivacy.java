package it.polimi.codekatabattle.entities;

public enum TournamentPrivacy {
    PUBLIC,
    PRIVATE,
}
