package it.polimi.codekatabattle.models.oauth;

public class OAuthAccessToken {
    public String access_token;
    public String token_type;
    public String scope;
}
