package it.polimi.codekatabattle.exceptions;

public class OAuthException extends Exception {

    public OAuthException(String message) {
        super(message);
    }

}
