CREATE DATABASE codekatabattle;
